import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { formatInTimeZone } from 'date-fns-tz';
import { Activity, CheckCircle2, XCircle, Clock, RefreshCw, BellRing, FileText, Award, FileCheck, Bell } from 'lucide-react';

interface Status {
  admitCardReleased: boolean;
  responseSheetReleased: boolean;
  resultReleased: boolean;
  lastChecked: string;
}

interface Log {
  id: number;
  timestamp: string;
  type: string;
  message: string;
  details: string;
}

export default function App() {
  const [status, setStatus] = useState<Status | null>(null);
  const [logs, setLogs] = useState<Log[]>([]);
  const [loading, setLoading] = useState(true);
  const [checking, setChecking] = useState(false);
  const [pushEnabled, setPushEnabled] = useState(false);

  useEffect(() => {
    if ('serviceWorker' in navigator && 'PushManager' in window) {
      navigator.serviceWorker.register('/sw.js').then(reg => {
        reg.pushManager.getSubscription().then(sub => {
          if (sub) setPushEnabled(true);
        });
      });
    }
  }, []);

  const subscribeToPush = async () => {
    if (!('serviceWorker' in navigator) || !('PushManager' in window)) {
      alert('Push notifications are not supported by your browser.');
      return;
    }

    try {
      const permission = await Notification.requestPermission();
      if (permission !== 'granted') {
        alert('Permission for notifications was denied');
        return;
      }

      const reg = await navigator.serviceWorker.ready;
      
      // Get public key from server
      const response = await axios.get('/api/vapidPublicKey');
      const vapidPublicKey = response.data;
      
      const convertedVapidKey = urlBase64ToUint8Array(vapidPublicKey);

      const subscription = await reg.pushManager.subscribe({
        userVisibleOnly: true,
        applicationServerKey: convertedVapidKey
      });

      await axios.post('/api/subscribe', subscription);
      setPushEnabled(true);
      alert('Successfully subscribed to push notifications!');
    } catch (error) {
      console.error('Failed to subscribe to push notifications:', error);
      alert('Failed to subscribe to push notifications.');
    }
  };

  // Utility function
  function urlBase64ToUint8Array(base64String: string) {
    const padding = '='.repeat((4 - base64String.length % 4) % 4);
    const base64 = (base64String + padding)
      .replace(/\-/g, '+')
      .replace(/_/g, '/');

    const rawData = window.atob(base64);
    const outputArray = new Uint8Array(rawData.length);

    for (let i = 0; i < rawData.length; ++i) {
      outputArray[i] = rawData.charCodeAt(i);
    }
    return outputArray;
  }

  const fetchData = async () => {
    try {
      const [statusRes, logsRes] = await Promise.all([
        axios.get('/api/status'),
        axios.get('/api/logs')
      ]);
      setStatus(statusRes.data);
      setLogs(logsRes.data);
    } catch (error) {
      console.error('Failed to fetch data:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
    const interval = setInterval(fetchData, 10000); // Poll every 10s
    return () => clearInterval(interval);
  }, []);

  const handleManualCheck = async () => {
    setChecking(true);
    try {
      await axios.post('/api/check');
      await fetchData();
    } catch (error) {
      console.error('Failed to trigger manual check:', error);
    } finally {
      setChecking(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 font-sans">
      {/* Header */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-10">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Activity className="h-6 w-6 text-blue-600" />
            <h1 className="text-xl font-bold tracking-tight">JEE Main Tracker</h1>
            <a 
              href="https://jeemain.nta.nic.in/" 
              target="_blank" 
              rel="noopener noreferrer"
              className="ml-4 text-sm font-medium text-blue-600 hover:text-blue-800 hidden sm:inline-block bg-blue-50 px-3 py-1 rounded-full"
            >
              Visit NTA Website &rarr;
            </a>
          </div>
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2 text-sm text-slate-500 hidden sm:flex">
              <Clock className="h-4 w-4" />
              <span>Last checked: {status?.lastChecked ? formatInTimeZone(new Date(status.lastChecked), 'Asia/Kolkata', 'MMM d, h:mm:ss a') + ' IST' : 'Never'}</span>
            </div>
            <button
              onClick={handleManualCheck}
              disabled={checking}
              className="inline-flex items-center gap-2 px-4 py-2 bg-blue-600 text-white text-sm font-medium rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:opacity-50 transition-colors"
            >
              <RefreshCw className={`h-4 w-4 ${checking ? 'animate-spin' : ''}`} />
              {checking ? 'Checking...' : 'Check Now'}
            </button>
            <button
              onClick={subscribeToPush}
              disabled={pushEnabled}
              className={`inline-flex items-center gap-2 px-4 py-2 text-sm font-medium rounded-md focus:outline-none focus:ring-2 focus:ring-offset-2 transition-colors ${
                pushEnabled 
                  ? 'bg-green-100 text-green-700 cursor-default' 
                  : 'bg-white border border-slate-300 text-slate-700 hover:bg-slate-50 focus:ring-slate-500'
              }`}
            >
              <Bell className="h-4 w-4" />
              {pushEnabled ? 'Notifications On' : 'Enable Alerts'}
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
        {/* Status Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <StatusCard
            title="Admit Card"
            icon={<FileText className="h-5 w-5" />}
            isReleased={status?.admitCardReleased}
            description="Hall ticket for examination"
          />
          <StatusCard
            title="Response Sheet"
            icon={<FileCheck className="h-5 w-5" />}
            isReleased={status?.responseSheetReleased}
            description="Provisional answer key & responses"
          />
          <StatusCard
            title="Result"
            icon={<Award className="h-5 w-5" />}
            isReleased={status?.resultReleased}
            description="Final scores and percentiles"
          />
        </div>

        {/* Logs Section */}
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
          <div className="px-6 py-5 border-b border-slate-200 flex items-center justify-between bg-slate-50/50">
            <h2 className="text-lg font-semibold flex items-center gap-2">
              <BellRing className="h-5 w-5 text-slate-500" />
              Activity Logs
            </h2>
            <span className="text-xs font-medium px-2.5 py-1 bg-slate-100 text-slate-600 rounded-full">
              Last 50 events
            </span>
          </div>
          <div className="divide-y divide-slate-100 max-h-[600px] overflow-y-auto">
            {logs.length === 0 ? (
              <div className="p-8 text-center text-slate-500">
                No logs available yet.
              </div>
            ) : (
              logs.map((log) => (
                <div key={log.id} className="p-4 sm:px-6 hover:bg-slate-50 transition-colors flex gap-4">
                  <div className="flex-shrink-0 mt-1">
                    {log.type === 'UPDATE' ? (
                      <div className="h-8 w-8 rounded-full bg-green-100 flex items-center justify-center">
                        <CheckCircle2 className="h-4 w-4 text-green-600" />
                      </div>
                    ) : log.type === 'ERROR' ? (
                      <div className="h-8 w-8 rounded-full bg-red-100 flex items-center justify-center">
                        <XCircle className="h-4 w-4 text-red-600" />
                      </div>
                    ) : (
                      <div className="h-8 w-8 rounded-full bg-blue-100 flex items-center justify-center">
                        <Activity className="h-4 w-4 text-blue-600" />
                      </div>
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-2">
                      <p className="text-sm font-medium text-slate-900 truncate">
                        {log.message}
                      </p>
                      <time className="text-xs text-slate-500 whitespace-nowrap">
                        {formatInTimeZone(new Date(log.timestamp), 'Asia/Kolkata', 'MMM d, h:mm:ss a')} IST
                      </time>
                    </div>
                    {log.details && (
                      <p className="mt-1 text-sm text-slate-500 whitespace-pre-wrap">
                        {log.details}
                      </p>
                    )}
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </main>
    </div>
  );
}

function StatusCard({ title, icon, isReleased, description }: { title: string, icon: React.ReactNode, isReleased?: boolean, description: string }) {
  return (
    <div className={`relative overflow-hidden rounded-xl border p-6 transition-all ${isReleased ? 'bg-green-50/50 border-green-200' : 'bg-white border-slate-200'}`}>
      <div className="flex items-center justify-between mb-4">
        <div className={`p-2 rounded-lg ${isReleased ? 'bg-green-100 text-green-700' : 'bg-slate-100 text-slate-600'}`}>
          {icon}
        </div>
        {isReleased ? (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium bg-green-100 text-green-800">
            <CheckCircle2 className="h-3.5 w-3.5" />
            Released
          </span>
        ) : (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium bg-slate-100 text-slate-600">
            <Clock className="h-3.5 w-3.5" />
            Pending
          </span>
        )}
      </div>
      <div>
        <h3 className="text-lg font-semibold text-slate-900">{title}</h3>
        <p className="text-sm text-slate-500 mt-1">{description}</p>
      </div>
      {isReleased && (
        <div className="mt-4 pt-4 border-t border-green-200/50">
          <a
            href="https://jeemain.nta.nic.in/"
            target="_blank"
            rel="noopener noreferrer"
            className="text-sm font-medium text-green-700 hover:text-green-800 flex items-center gap-1"
          >
            Go to official website &rarr;
          </a>
        </div>
      )}
    </div>
  );
}
